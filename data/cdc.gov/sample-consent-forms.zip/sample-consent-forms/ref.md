[Directions: Sample Consent Forms](https://www.cdc.gov/od/foia/forms/index.htm)  

## Sample Consent Forms  

### CDC/ATSDR  

[Authorization for Release of Records](https://www.cdc.gov/od/foia/docs/cdc_atsdradult.pdf)  
[Authorization for Release of Minor's Records](https://www.cdc.gov/od/foia/docs/cdc_atsdrminor.pdf)  

### NIOSH  

[Authorization for Release of Records](https://www.cdc.gov/od/foia/docs/nioshadult.pdf)  