<div class="item-page">

	<h2>
			FOIA - ODNI FOIA Reports		</h2>
<div class="icons-align">



</div>





	<table style="width: 100%;" border="0">
<tbody>
<tr>
<td height="2" bgcolor="#000000"></td>
</tr>
</tbody>
</table>
<a href="/index.php/about-this-site/foia"><img src="/files/images/foia/portal_banner_thin.png" alt="portal banner thin" width="850" height="92"></a>
<table style="width: 100%;" border="0">
<tbody>
<tr>
<td height="2" bgcolor="#000000"></td>
</tr>
<tr>
<td height="5" bgcolor="#ffffff"></td>
</tr>
<tr>
<td height="2" bgcolor="#000000"></td>
</tr>
<tr>
<td height="20" bgcolor="#505050 "></td>
</tr>
</tbody>
</table>
<table style="width: 100%;" border="0" bgcolor="#505050 ">
<tbody>
<tr>
<td rowspan="10" width="5%" bgcolor="#505050 "></td>
<td rowspan="10" bgcolor="#505050 "><span style="float: left; color: #c5b358; font-size: 80px; line-height: 30px; padding-top: 10px; padding-bottom: 0px; padding-right: 3px; padding-left: 0px;"><br>T</span><span style="color: #ffffff; font-size: 14pt;"><br>he goal of the ODNI <strong>Freedom of Information Act</strong> / <strong>Privacy Act</strong> office is to keep the public better informed about the agency’s efforts and to ensure U.S. security through the release of as much information as possible, consistent with the need to protect classified or sensitive information under the exemption provisions of these laws.</span></td>
<td rowspan="10" width="5%" bgcolor="#505050 "></td>
</tr>
<tr>
<td><img onmouseover="this.src='/files/images/foia/buttons/make_request_hover.png';" onmouseout="this.src='/files/images/foia/buttons/make_request.png';" src="/files/images/foia/buttons/make_request.png" alt="make request" width="420" height="40"></td>
</tr>
<tr>
<td height="5" bgcolor="#505050 "></td>
</tr>
<tr>
<td><a href="/index.php/about-this-site/foia/foia-checking-the-status-of-a-request"><img onmouseover="this.src='/files/images/foia/buttons/check_status_hover.png';" onmouseout="this.src='/files/images/foia/buttons/check_status.png';" src="/files/images/foia/buttons/check_status.png" alt="Check the Status of a Records Request" width="420" height="40"></a></td>
</tr>
<tr>
<td height="5" bgcolor="#505050 "></td>
</tr>
<tr>
<td><a href="/index.php/about-this-site/foia/read-released-records"><img onmouseover="this.src='/files/images/foia/buttons/read_hover.png';" onmouseout="this.src='/files/images/foia/buttons/read.png';" src="/files/images/foia/buttons/read.png" alt="read" width="420" height="40"></a></td>
</tr>
<tr>
<td height="5" bgcolor="#505050 "></td>
</tr>
<tr>
<td><a href="/index.php/about-this-site/foia/odni-foia-log"><img onmouseover="this.src='/files/images/foia/buttons/view_log_hover.png';" onmouseout="this.src='/files/images/foia/buttons/view_log.png';" src="/files/images/foia/buttons/view_log.png" alt="View ODNI FOIA Log" width="420" height="40"></a></td>
</tr>
<tr>
<td height="5" bgcolor="#505050 "></td>
</tr>
<tr>
<td><img onmouseover="this.src='/files/images/foia/buttons/download_reports_hover.png';" onmouseout="this.src='/files/images/foia/buttons/download_reports_hover.png';" src="/files/images/foia/buttons/download_reports_hover.png" alt="Download ODNI FOIA Reports" width="420" height="40"></td>
</tr>
<tr>
<td height="5px" bgcolor="#505050 "></td>
</tr>
</tbody>
</table>
<table style="width: 100%;" border="0" bgcolor="#505050 ">
<tbody>
<tr>
<td colspan="6" height="35" bgcolor="#505050 "></td>
</tr>
<tr>
<td colspan="6" height="7" bgcolor="#c5b358"></td>
</tr>
<tr>
<td width="5%" bgcolor="ffffff"></td>
<td colspan="4" height="5" bgcolor="#ffffff">
<h3><strong>Quartely FOIA Reports</strong></h3>
<ul>
<li><a title="ODNI FOIA Report Q1 2016 " href="/files/documents/FOIA/ODNI-2016-Q1.zip">ODNI FOIA Report Q1 2016 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q3 2015 " href="/files/documents/FOIA/ODNI-2015-Q3.zip">ODNI FOIA Report Q3 2015 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q2 2015 " href="/files/documents/FOIA/ODNI-2015-Q2.zip">ODNI FOIA Report Q2 2015 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q1 2015 " href="/files/documents/FOIA/ODNI-2015-Q1.zip">ODNI FOIA Report Q1 2015 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q1 2014 " href="/files/documents/FOIA/ODNI-2014-Q1.zip">ODNI FOIA Report Q1 2014 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q4 2013 " href="/files/documents/FOIA/ODNI-2013-Q4.zip">ODNI FOIA Report Q4 2013 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q3 2013 " href="/files/documents/FOIA/ODNI-2013-Q3[1].zip">ODNI FOIA Report Q3 2013 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q2 2013 " href="/files/documents/FOIA/ODNI-2013-Q2.zip">ODNI FOIA Report Q3 2013 (JSON/XML.zip)</a></li>
<li><a title="ODNI FOIA Report Q1 2013 " href="/files/documents/FOIA/ODNI-2013-Q1.zip">ODNI FOIA Report Q1 2013 (JSON/XML.zip)</a></li>
</ul>
<h3><br>Chief FOIA Office Reports</h3>
<ul style="list-style-type: square;">
<li><a title="ODNI Chief FOIA Officer Report 2016" href="/files/documents/FOIA/Updated%202016%20Chief%20FOIA%20report%20-%20Final.pdf">ODNI Chief FOIA Officer Report 2016</a></li>
<li><a title="ODNI Chief FOIA Officer Report 2015" href="/files/documents/FOIA/ODNI%20Chief%20FOIA%20Officer%20Report%202015.pdf">ODNI Chief FOIA Officer Report 2015</a></li>
<li><a href="/files/documents/FOIA/ODNI%20FY14%20Chief%20FOIA%20Report%20FINAL%2020140414.pdf">ODNI Chief FOIA Officer Report 2014</a></li>
<li><a href="/files/documents/FOIA/FY13%20Chief%20FOIA%20Report.pdf">ODNI Chief FOIA Officer Report 2013</a></li>
<li><a title="ODNI Chief FOIA Officer Report 2012" href="/files/documents/FOIA/odni_chief_foia_officer_report_2012.pdf" target="_blank">ODNI Chief FOIA Officer Report 2012</a></li>
<li><a title="ODNI Chief FOIA Officer Report 2011" href="/files/documents/FOIA/odni_chief_foia_officer_report_2011.pdf" target="_blank">ODNI Chief FOIA Officer Report 2011</a></li>
<li><a title="ODNI Chief FOIA Officer Report 2010" href="/files/documents/FOIA/odni_chief_foia_officer_report_2010.pdf" target="_blank">ODNI Chief FOIA Officer Report 2010</a></li>
</ul>
<h3><br>FOIA Annual Report</h3>
<ul style="list-style-type: square;">
<li><a title="2015 Annual Report" href="/files/documents/FOIA/ODNI%20FY15%20Annual%20FOIA%20Report.pdf">2015 Annual Report</a> <a title="XML" href="/files/documents/FOIA/ODNI%20FY%202015%20(Final).xml">(XML)</a></li>
<li><a href="/files/documents/FOIA/ODNI%20FY14%20Annual%20FOIA%20Report.pdf">2014 Annual Report</a> <a href="/files/documents/FOIA/ODNI%20FY14%20(Final).xml">(XML)</a></li>
<li><a title="2013 Annual Report" href="/files/documents/FOIA/ODNI%20FY13%20Annual%20FOIA%20Report.pdf">2013 Annual Report</a> <a title="(XML)" href="/files/documents/FOIA/ODNI.FY13.Final.xml">(XML)</a></li>
<li><a href="/files/documents/FOIA/ODNI%20FY12%20Final.pdf">2012 Annual Report</a> (<a title="2012 Annual Report" href="/files/documents/FOIA/ODNI.FY12.Final.xml">XML</a>)</li>
<li><a title="2011 Annual Report" href="/files/documents/FOIA/fy11_annual_report.pdf" target="_blank">2011 Annual Report</a></li>
<li><a title="2010 Annual Report" href="/files/documents/FOIA/fy10_annual_report.pdf" target="_blank">2010 Annual Report</a></li>
<li><a title="2009 Annual Report " href="/files/documents/FOIA/fy09_annual_report.pdf" target="_blank">2009 Annual Report </a></li>
<li><a title="2008 Annual Report" href="/files/documents/FOIA/fy08_annual_report.pdf" target="_blank">2008 Annual Report</a></li>
<li><a title="2007 Annual Report" href="/files/documents/FOIA/2007%20annual_report_final.pdf" target="_blank">2007 Annual Report</a></li>
<li><a title="2006 Annual Report" href="/files/documents/FOIA/odni_fy06_annual_foia.pdf" target="_blank">2006 Annual Report</a></li>
<li><a title="2005 Annual Report" href="/files/documents/FOIA/odni_fy05_annual_foia.pdf" target="_blank">2005 Annual Report</a></li>
</ul>
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td colspan="6" height="7" bgcolor="#c5b358"></td>
</tr>
<tr>
<td colspan="6" height="25" bgcolor="#505050 "></td>
</tr>
<tr>
<td width="5%" bgcolor="#505050 "></td>
<td style="text-align: left; vertical-align: top;" width="30%" valign="top" bgcolor="#505050"><span style="font-size: 18pt; color: #c5b358;">FOIA RESOURCES:</span></td>
<td width="30%" bgcolor="#505050 "></td>
<td width="30%" bgcolor="#505050 "></td>
<td width="5%" bgcolor="#505050 "><span style="color: #ffffff; font-size: 12pt;">&nbsp;</span></td>
</tr>
<tr>
<td colspan="6" height="10" bgcolor="#505050 "></td>
</tr>
<tr>
<td width="5%" bgcolor="#505050 "></td>
<td style="text-align: left; vertical-align: top;" width="35%" valign="top" bgcolor="#505050 ">
<ul style="list-style-type: square;">
<li><span style="font-size: 12pt; color: #ffffff;"><strong><a href="http://www.dni.gov/index.php/intelligence-community/ic-policies-reports"><span style="color: #ffffff;">ODNI Electronic Reading Room</span></a></strong></span></li>
<li><a href="http://www.dni.gov/files/documents/FOIA/ODNI_Open_Gov_Plan.pdf"><span style="font-size: 12pt; color: #ffffff;"><strong>ODNI Open Government Plan</strong></span></a><strong></strong></li>
<li><strong><span style="font-size: 12pt; color: #ffffff;"><a title="ODNI FOIA Handbook" href="http://www.dni.gov/files/documents/FOIA/odni_foia_handbook.pdf" target="_blank"><span style="color: #ffffff;">ODNI FOIA Handbook</span></a></span></strong></li>
</ul>
</td>
<td style="text-align: left; vertical-align: top;" width="30%" valign="top" bgcolor="#505050 ">
<ul style="list-style-type: square;">
<li><span style="font-size: 12pt;"><strong><a title="FOIA Regulations" href="http://www.dni.gov/files/documents/FOIA/foia%20regs.pdf" target="_blank"><span style="color: #ffffff;">FOIA Regulations</span></a></strong></span></li>
<li><span style="color: #ffffff; font-size: 12pt;"><strong><a title="ODNI FOIA Reading Room Certification" href="/files/documents/FOIA/ofr.pdf" target="_blank"><span style="color: #ffffff;">ODNI FOIA Reading Room Certification</span></a></strong></span><strong></strong></li>
</ul>
<p><br style="color: #ffffff;"><strong></strong></p>
</td>
<td width="25%" valign="top" bgcolor="#505050 ">
<ul style="list-style-type: square;">
<li><span style="font-size: 12pt; color: #ffffff;"><strong><a title="Backlog Reduction Plan" href="/files/documents/FOIA/backlog%20reduction%20plan.pdf" target="_blank"><span style="color: #ffffff;">Backlog Reduction Plan</span></a></strong></span></li>
<li><span style="font-size: 12pt; color: #ffffff;"><strong><a title="ODNI FOIA Handbook" href="http://www.dni.gov/files/documents/FOIA/odni_foia_handbook.pdf" target="_blank"><span style="color: #ffffff;">Other IC FOIA Websites</span></a></strong></span></li>
<li><a title="ODNI FOIA Handbook" href="/files/documents/FOIA/2016-03-24_Memo_FCGR.pdf" target="_blank"><span style="font-size: 12pt; color: #ffffff;"><strong><span style="color: #ffffff;">DNI FCGR Memo</span></strong></span></a></li>
</ul>
</td>
<td width="5%" bgcolor="#505050 "><span style="color: #ffffff; font-size: 12pt;">&nbsp;</span></td>
</tr>
</tbody>
</table>
	</div>