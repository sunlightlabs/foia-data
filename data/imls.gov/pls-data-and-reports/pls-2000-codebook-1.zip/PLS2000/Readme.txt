Welcome to the PLS 2000 (Windows).  These sets of files provide all
available data and electronic codebooks (ECBs) for the following 
PLS 2000 survey components:
  L0P -- Public Library Data File, FY 2000
  S0P -- State Summary/State Characteristics Data File, FY 2000
  O0P -- Public Library Outlet File, FY 2000


Contents and Directory/Subdirectory Structure.

\PLS2000  
This directory contains the README.TXT file (ASCII) you are 
reading now.  

\PLS2000\ECBW
Contains all of the ECB files required for running the system and 
subdirectories that contain component descriptive information used 
by the ECB.

\PLS2000\DATA
Contains the PLS data files (as opposed to ECB files).

\PLS2000\DOCUMENTATION
Contains the PLS 2000 documentation file.


How To Install the Windows ECBs

The instructions that follow guide you through the simple 
steps you must take to successfully begin to use the PLS 
ECB.

2.1  Installation of the Windows ECB

Space requirements:  The PLS2000.ZIP file is approx. 4.18M.  This 
file when decompressed is approx. 13.3M.  The Installation of one 
Windows ECB requires about 540KB and if all three PLS2000 component 
engines (project ids: L0P, O0P, and S0P) are installed, they will 
require an additional 193.3K of space on any writeable drive.

To install the ECB:

1.  Turn on your PC, allowing it to boot up.

2.  Determine whether there is enough free disk space to install 
    the ECB application.

3.  From the Windows START, under Run, run the 
    ECB setup program (SETUP.EXE) contained in the PLS2000 
    subdirectory /ECBW.

4.  The setup program will guide you through installation of 
    the ECB, prompting you with questions concerning the 
    ECB that you wish to install, and the installation drive 
    and subdirectory.

5.  The setup program will create an Electronic Codebook program 
    group and program item for each selected PLS 2000 component 
    ECB (project id: L0P, O0P, or S0P) at installation time.  To run
    one of these ECB components, just double click on its icon, within
    the Electronic Codebook program group or see general comment #2 
    below.

2.2  Installed ECB application

General comments:

1.  If defaults are used when installing the ECB engine and project 
    files, a copy of application files will be stored in C:\ECBW\ and
    associated project directories (L0P, O0P, and S0P) off of C:\ECBW\.
    The original directory structure and files created when decompressing
    PLS2000.ZIP will remain in their designated location.  This includes 
    all the documentation and data files.  One advantage of using the 
    C:\ECBW\ default is that other NCES ECB projects can be installed in
    a central location off of a single ECB engine stored in C:\ECBW\. 

2.  To run the installed ECB, the user can left click START, then PROGRAMS,
    then Electronic Codebook, and finally click the desired PLS 2000 survey
    component (L0P - Public library Data 2000 public-use;  O0P - Public 
    Library Outlets 2000 public-use; or S0P - State Summary/State Characteristics
    2000 public-use).

3.  After tagging a list of variables, for creating an extract analysis file,
    the user can generate output by clicking FILE, then OUTPUT, and then the 
    desired output format (e.g, SAS-PC for generated SAS code to extract from 
    PLS 2000 flat ASCII data files).  These output files will be stored in 
    the project (L0P, O0P, or S0P) subdirectories off of the specified target
    directory defined in installation (default was C:\ECBW\).  If the user 
    should wish to change this output designation, they can click on FILE, 
    then SETUP, and specify the desired drive and path for Output Directory.
    Note:  One of the setup change options is CD-ROM Drive.  This is the
    disk drive or CD-ROM Drive which contains the PLS 2000 data found in 
    directory \PLS2000\DATA. 

4.  Prior to running generated SAS-PC or SPSS code, check that the path
    designation for \PLS2000\DATA is correct and make appropriate changes.



Thorough documentation of the main ECB features is provided 
by the online help function of the Windows ECB system; it is 
strongly recommended that the user review this online 
documentation before using the Windows ECB.