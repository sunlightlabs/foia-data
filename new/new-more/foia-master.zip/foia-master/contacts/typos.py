"""Collection of tweaks to fix FOIA data"""

# see http://foia.msfc.nasa.gov/reading.html
REPLACEMENTS = {
    "(256) 544-007 ": "(256) 544-0007 "
}
