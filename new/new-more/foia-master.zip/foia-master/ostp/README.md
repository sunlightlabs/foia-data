## Office of Science and Technology Policy

FOIA resources and links.

#### Make a FOIA request

Email [ostpfoia@ostp.eop.gov](mailto:ostpfoia@ostp.eop.gov).

They have [instructions and a summary of their regulations](http://www.whitehouse.gov/administration/eop/ostp/library/foia/requests).

#### Status of FOIA requests

You have to email them to find out.

#### Responses and Documents

Their [FOIA Library](http://www.whitehouse.gov/administration/eop/ostp/library/foia/readingroom) has a very, very few documents, none of which appear to be tied to individual FOIA requests. It also contains their annual FOIA reports, which are published as matter of routine.
