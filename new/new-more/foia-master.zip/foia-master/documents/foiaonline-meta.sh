#!/usr/bin/sh

python tasks/foiaonline.py --meta --term=epa
python tasks/foiaonline.py --meta --term=cbp
python tasks/foiaonline.py --meta --term=doc
python tasks/foiaonline.py --meta --term=mspb
python tasks/foiaonline.py --meta --term=flra
python tasks/foiaonline.py --meta --term=nara
python tasks/foiaonline.py --meta --term=pbgc
python tasks/foiaonline.py --meta --term=don
